/* 
     CSC139 Spring 2023
     First Assignment
     Algador, Vigomar Kim
     Section # 03
*/

#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>


struct QNode {
     int process;
     struct QNode *next;
};

struct Queue {
     struct QNode *front, *rear;
};

struct QNode* newQNode(int process) {
    struct QNode* temp = (struct QNode*)malloc(sizeof(struct QNode));
    temp->process = process;
    temp->next = NULL;
    return temp;
}

struct Queue* createQueue() {
    struct Queue* queue = (struct Queue*)malloc(sizeof(struct Queue));
    queue->front = queue->rear = NULL;
    return queue;
}

void enQueue(struct Queue* queue, int process) {
    struct QNode* temp = newQNode(process);
 
    if (queue->rear == NULL) {
        queue->front = queue->rear = temp;
        return;
    }
    
    queue->rear->next = temp;
    queue->rear = temp;
}

int deQueue(struct Queue* queue) {
    struct QNode* temp = queue->front;
    int process = queue->front->process;
    queue->front = queue->front->next;
 
    if (queue->front == NULL)
        queue->rear = NULL;

    free(temp);
    return process;
}

int peekQueue(struct Queue* queue) {
    return queue->front->process;
}

bool isEmpty(struct Queue* queue) {
	return queue->front == NULL;
}

struct BSTNode {
	int data;
	int process;
	struct BSTNode *left, *right;
};

struct BSTNode *newBSTNode(int process, int data) {
  struct BSTNode *temp = (struct BSTNode *)malloc(sizeof(struct BSTNode));
  temp->process = process;
  temp->data = data;
  temp->left = temp->right = NULL;
  return temp;
}

struct BSTNode *insert(struct BSTNode *BSTNode, int process, int data) {
    // Return a new node if the tree is empty
    if (BSTNode == NULL) 
        return newBSTNode(process, data);

    // Traverse to the right place and insert the node
    if (data < BSTNode->data)
        BSTNode->left = insert(BSTNode->left, process, data);
    else
        BSTNode->right = insert(BSTNode->right, process, data);

    return BSTNode;
}

void inorder(struct BSTNode *root, struct Queue *queue) {
	if (root != NULL) {
		inorder(root->left, queue);	// Traverse left
		enQueue(queue, root->process);
		inorder(root->right, queue);	// Traverse right
  	}
}

void schedulingSelect(FILE *inputFile, FILE *outputFile);
void roundRobin(FILE *inputFile, FILE *outputFile);
void shortestJobFirst(FILE *inputFile, FILE *outputFile);
void priorityNoPREMP(FILE *inputFileFILE, FILE *outputFile);
void priorityWithPREMP(FILE *inputFile, FILE *outputFile);
void inorder(struct BSTNode *root, struct Queue *queue);

int main () {
     char fileName[50];		// variable for the name of the file
	FILE *inputFile;
     FILE *outputFile;

	printf("Please enter the file name: ");
	scanf( "%s", fileName);
	inputFile = fopen(fileName,"r");

	if(inputFile == NULL) {
		printf("Error: Unable to open %s\n", fileName);
		exit(1);
	}

     outputFile = fopen("output.txt","w");

     if(outputFile == NULL) {
		printf("Error: Unable to open %s\n", fileName);
		exit(1);
	}

	schedulingSelect(inputFile,outputFile);
	fclose(inputFile);
     fclose(outputFile);
}

void schedulingSelect(FILE *inputFile, FILE *outputFile) {
	char scheduling[50];

	fscanf(inputFile, "%s", scheduling);
     fprintf(outputFile,"%s\n",scheduling);
	printf("%s\n",scheduling);

	if(strcasecmp(scheduling,"rr") == 0)
		roundRobin(inputFile, outputFile);
	else if (strcasecmp(scheduling,"sjf") == 0)
		shortestJobFirst(inputFile,outputFile);
	else if (strcasecmp(scheduling, "PR_noPREMP") == 0)
		priorityNoPREMP(inputFile,outputFile);
	else if (strcasecmp(scheduling, "PR_withPREMP") == 0)
		priorityWithPREMP(inputFile, outputFile);
	else
		printf("Cannot read CPU scheduling.\n");
}

void roundRobin(FILE *inputFile, FILE *outputFile) {
	int quantum, processNum;
	int prevProcess = 0;
	int sum = 0;
	int processCount= 0;
	int nextWait = 0, wait = 0;
	float ave;
    int process;

	fscanf(inputFile, "%d", &quantum);
	fscanf(inputFile, "%d", &processNum);

     struct Queue *RR = createQueue();
     struct Queue *output = createQueue();

     int burstNum[processNum + 1];
     int WT[processNum + 1][2];
     int BT;

	for (int i = 1; i <= processNum; i++) {
		fscanf(inputFile,"%*d %*d %d %*d",&burstNum[i]);
		enQueue(RR, i);
        WT[i][0] = -1;
        WT[i][1] = 0;
	}

     while (!isEmpty(RR)) {
        process = deQueue(RR);
        if (burstNum[process] <= quantum) {
            nextWait += burstNum[process];
            BT = burstNum[process];
		}
		else {
			burstNum[process] -= quantum;
			nextWait += quantum;
            BT = quantum;
			enQueue(RR, process);
		}
        
        if (prevProcess != process) {
            if (WT[process][0] < 0)
                WT[process][0] = wait;
            else {
                WT[process][0] += (wait - (WT[process][0] + WT[process][1]));
            }
        }
          
        fprintf(outputFile, "%d\t%d\n", wait, process);
        printf("%d\t%d\n", wait, process);
        WT[process][1] = BT;
        wait = nextWait;
        prevProcess = process;
     }

     for (int i = 1; i <= processNum; i++)
               sum += WT[i][0];

    ave = (float) sum / processNum;
    fprintf(outputFile, "AVG waiting time: %0.2f\n", ave);
	printf("AVG waiting time: %0.2f\n", ave);
}

void shortestJobFirst(FILE *inputFile, FILE *outputFile) {
	int processNum;

	fscanf(inputFile, "%d", &processNum);
	int burst[processNum + 1];
	int AT[processNum + 1];
	int process, priority;
	int wait = 0;
	int sum = 0;
	float ave;
	int P1, P2, temp;
	int Arrive = 0;
	int maxArrival = 0;


	struct BSTNode *SJFArrival = NULL;
	struct BSTNode *bst = NULL;
	struct Queue *SJF = createQueue();
	struct Queue *queue = createQueue();

	for (int i = 1; i <= processNum; i++) {
		fscanf(inputFile,"%*d %d %d %*d", &AT[i], &burst[i]);
		enQueue(SJF,i);

		if (maxArrival < AT[i])
			maxArrival = AT[i];
	}

	if (maxArrival > 0) {

		while (!isEmpty(SJF)) {
			process = deQueue(SJF);
			SJFArrival = insert(SJFArrival, process, AT[process]);
		}

		inorder(SJFArrival, SJF);

		P1 = deQueue(SJF);
		Arrive = AT[peekQueue(SJF)];

		while (!isEmpty(SJF)) {
		P2 = deQueue(SJF);

		if (P2[AT] >= Arrive) {
			if (burst[P1] <=burst[P2]) {
				enQueue(queue,P1);
			 	Arrive = burst[P1] + burst[P2];
			}
			else {
			 	bst = insert(bst, P1, burst[P1] - AT[P2]);
			 	Arrive = AT[P2];
			}

			enQueue(queue,P2);
			
		}
		else {
		  bst = insert(bst, P2, burst[P2]);
		}

		P1 = P2;
		}
	}
	else {
		while (!isEmpty(SJF)) {
			process = deQueue(SJF);
			bst = insert(bst, process, burst[process]);
		}
	}
    
    inorder(bst, queue);

    while (!isEmpty(queue)) {
        process = deQueue(queue);
        fprintf(outputFile, "%d\t%d\n", wait, process);
        printf("%d\t%d\n",wait, process);
        sum += wait;
        wait += burst[process];
    } 

    ave = (float) sum / processNum;
    fprintf(outputFile, "AVG waiting time: %0.2f\n", ave);
	printf("AVG waiting time: %0.2f\n", ave);

}	

void priorityNoPREMP(FILE *inputFile, FILE *outputFile) {
	int processNum;

	fscanf(inputFile, "%d", &processNum);
	int burst[processNum + 1];
    int process, priority;
    int wait = 0;
	int sum = 0;
	float ave;

    struct BSTNode *bst = NULL;
    struct Queue *queue = createQueue();

	for (int i = 1; i <= processNum; i++) {
		fscanf(inputFile,"%*d %*d %d %d", &burst[i], &priority);
        bst = insert(bst, i, priority);
     }
     
     inorder(bst, queue);

    while (!isEmpty(queue)) {
        process = deQueue(queue);
        fprintf(outputFile, "%d\t%d\n", wait, process);
        printf("%d\t%d\n",wait, process);
        sum += wait;
        wait += burst[process];
    } 

    ave = (float) sum / processNum;
    fprintf(outputFile, "AVG waiting time: %0.2f\n", ave);
	printf("AVG waiting time: %0.2f\n", ave);

}

void priorityWithPREMP(FILE *inputFile, FILE *outputFile) {
	int processNum;

	fscanf(inputFile, "%d", &processNum);
	int burst[processNum + 1];
    int process, priority;
    int wait = 0;
	int sum = 0;
	float ave;

    struct BSTNode *bst = NULL;
    struct Queue *queue = createQueue();

	for (int i = 1; i <= processNum; i++) {
		fscanf(inputFile,"%*d %*d %d %d", &burst[i], &priority);
        bst = insert(bst, i, priority);
     }
     
     inorder(bst, queue);

    while (!isEmpty(queue)) {
        process = deQueue(queue);
        fprintf(outputFile, "%d\t%d\n", wait, process);
        printf("%d\t%d\n",wait, process);
        sum += wait;
        wait += burst[process];
    } 

    ave = (float) sum / processNum;
    fprintf(outputFile, "AVG waiting time: %0.2f\n", ave);
	printf("AVG waiting time: %0.2f\n", ave);
}


