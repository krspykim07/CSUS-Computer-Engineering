
// Vigomar Kim Algador
// CSC130-03
// Game Project

package Main;

import java.awt.Color;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

import Data.Vector2D;
import Data.spriteInfo;
import logic.Control;
import timer.stopWatchX;

public class Main{
	// Fields (Static) below...
	public static Color skyBlue = new Color(135,206,235);	// Sky Blue Color
	public static boolean isImageDrawn = false;
	public static stopWatchX timer = new stopWatchX(100);
	//public static Queue<Vector2D> vecs1 = new LinkedList<>();
	//public static Queue<Vector2D> vecs2 = new LinkedList<>();
	//public static Vector2D currentVec = new Vector2D (-100,-100);
	
	public static ArrayList<spriteInfo> sprites = new ArrayList<>();
	public static int currentSpriteIndex = 0;
	
	
	// End Static fields...
	
	public static void main(String[] args) {
		Control ctrl = new Control();				// Do NOT remove!
		ctrl.gameLoop();							// Do NOT remove!
	}
	
	/* This is your access to things BEFORE the game loop starts */
	public static void start(){
		// TODO: Code your starting conditions here...NOT DRAW CALLS HERE! (no addSprite or drawString)
		int position = 1;
		for(int steps = -120; steps < 1440; steps+=20) {
			switch (position) {
			case 1: case 3: 
				sprites.add(new spriteInfo(new Vector2D(steps, 50), "IUrightstand"));
				break;
			case 2:
				sprites.add(new spriteInfo(new Vector2D(steps, 50), "IUrightwalk01"));
				break;
			case 4:
				sprites.add(new spriteInfo(new Vector2D(steps, 50), "IUrightwalk02"));
				break;
			default:
				sprites.add(new spriteInfo(new Vector2D(steps, 50), "IUrightstand"));
				break;
			}
			
			position++;
			if(position > 5)
				position = 1;
		}
	}
	
	/* This is your access to the "game loop" (It is a "callback" method from the Control class (do NOT modify that class!))*/
	public static void update(Control ctrl) {
		// TODO: This is where you can code! (Starting code below is just to show you how it works)
		int n = sprites.size();
		spriteInfo tmp = sprites.get(currentSpriteIndex);
		
		ctrl.addSpriteToFrontBuffer(tmp.getCoords().getX(), tmp.getCoords().getY(), tmp.getTag());					// Add a tester sprite to render list by tag (Remove later! Test only!)
		
		
		if(timer.isTimeUp()) {
			isImageDrawn = !isImageDrawn;
			currentSpriteIndex++;
			timer.resetWatch();
		}
		
		if(currentSpriteIndex >= n) {		//serves as reset movement
			currentSpriteIndex = 0;
		}
		
	}
	
	// Additional Static methods below...(if needed)

}
